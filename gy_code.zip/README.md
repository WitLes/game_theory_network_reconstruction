# game_theory_network_reconstruction
Reproduction of the article below:

Wang W X, Lai Y C, Grebogi C, et al. Network reconstruction based on evolutionary-game data via compressive sensing[J]. Physical Review X, 2011, 1(2): 021021.
