from lib.evolutionary_game import *

run()